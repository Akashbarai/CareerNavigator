<?php include 'templates/header.php'; ?>
<?php include 'db.php'; ?>

<div class="form-container">
    <h1>Create Your Profile</h1>

    <form method="POST" action="recommendations.php">
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
        </div>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>

        <div class="form-group">
            <label for="educational_details">Educational Details (e.g., High School, VET, University):</label>
            <textarea id="educational_details" name="educational_details" rows="4" required></textarea>
        </div>

        <div class="form-group">
            <label for="field_of_interest">Field of Interest (e.g., Technology, Healthcare, Construction):</label>
            <textarea id="field_of_interest" name="field_of_interest" rows="4" required></textarea>
        </div>

        <div class="form-group">
            <label for="skills">Skills (e.g., Problem Solving, Programming, Communication):</label>
            <textarea id="skills" name="skills" rows="4" required></textarea>
        </div>

        <div class="form-group">
            <label for="location">Location (State or Territory):</label>
            <input type="text" id="location" name="location" required>
        </div>

        <div class="form-group">
            <label for="financial_condition">Financial Condition (e.g., Financial Aid Required, Self-Sufficient):</label>
            <textarea id="financial_condition" name="financial_condition" rows="4" required></textarea>
        </div>

        <div class="form-submit">
            <input type="submit" value="Submit">
        </div>
    </form>
</div>

<?php include 'templates/footer.php'; ?>
