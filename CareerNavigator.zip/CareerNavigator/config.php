<?php
// config.php - Store API keys securely

// Job Outlook API Key (Australian Government)
define('JOB_OUTLOOK_API_KEY', 'your_job_outlook_api_key');

// Google Jobs API Key
define('GOOGLE_JOBS_API_KEY', 'your_google_jobs_api_key');

// LinkedIn API Key
define('LINKEDIN_API_KEY', 'your_linkedin_api_key');

// Twitter API Key (For career-related trends)
define('TWITTER_API_KEY', 'your_twitter_api_key');
?>
