<?php include 'templates/header.php'; ?>
<?php include 'db.php'; ?>

<h1>Career Recommendations</h1>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the user input from the form submission
    $name = $_POST['name'];
    $email = $_POST['email'];
    $educational_details = $_POST['educational_details'];
    $field_of_interest = $_POST['field_of_interest'];
    $skills = $_POST['skills'];
    $location = $_POST['location'];
    $financial_condition = $_POST['financial_condition'];

    // Insert student data into the database
    $sql = "INSERT INTO students (name, email, educational_details, field_of_interest, skills, location, financial_condition)
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$name, $email, $educational_details, $field_of_interest, $skills, $location, $financial_condition]);

    // Display recommendations
    echo "<div class='recommendations-container'>";
    echo "<h2>Hello, " . htmlspecialchars($name) . "!</h2>";
    echo "<p>Based on your profile, here are some general career recommendations:</p>";

    echo "<div class='recommendation-card'>";
    echo "<strong>Industry:</strong> Marketing<br>";
    echo "<strong>Recommended Subject:</strong> Business Administration or Marketing<br>";
    echo "<strong>Projected Growth:</strong> 10% over the next 5 years<br>";
    echo "<strong>Average Salary:</strong> $80,000/year<br>";
    echo "</div>";

    echo "<div class='recommendation-card'>";
    echo "<strong>Industry:</strong> Project Management<br>";
    echo "<strong>Recommended Subject:</strong> Project Management or Business Studies<br>";
    echo "<strong>Projected Growth:</strong> 12% over the next 5 years<br>";
    echo "<strong>Average Salary:</strong> $85,000/year<br>";
    echo "</div>";

    echo "</div>";
}
?>

<?php include 'templates/footer.php'; ?>
