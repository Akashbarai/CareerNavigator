<?php include 'templates/header.php'; ?>
<?php include 'db.php'; ?>

<div class="admin-container">
    <h1>Admin - Fetch Latest Labor Market Trends</h1>

    <!-- Form to fetch labor market trends -->
    <form method="POST" class="trend-form">
        <div class="form-group">
            <label for="field_of_interest">Field of Interest (e.g., Technology, Healthcare):</label>
            <input type="text" id="field_of_interest" name="field_of_interest" required>
        </div>

        <div class="form-group">
            <label for="location">Location (State or Territory):</label>
            <input type="text" id="location" name="location" required>
        </div>

        <div class="form-submit">
            <input type="submit" value="Fetch Trends">
        </div>
    </form>

    <!-- Add link to view student submissions -->
    <div class="admin-actions">
        <h2>Admin Actions</h2>
        <p>Click the button below to view all submitted student profiles:</p>
        <a href="admin_view_students.php" class="cta-primary">View Submitted Student Profiles</a>
    </div>

    <?php
    // Fetch trends data logic can remain the same as earlier
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Simulated fetch trends data logic...
        $field_of_interest = $_POST['field_of_interest'];
        $location = $_POST['location'];
        $trends = null;

        if (!$trends) {
            echo "<p class='no-trends'>No trends found for the given field of interest and location.</p>";
        } else {
            echo "<div class='trend-results'>";
            echo "<h2>Labor Market Trends</h2>";
            foreach ($trends as $trend) {
                echo "<div class='trend-card'>";
                echo "<strong>Industry:</strong> " . $trend['industry'] . "<br>";
                echo "<strong>Projected Growth:</strong> " . $trend['growth'] . "%<br>";
                echo "<strong>Average Salary:</strong> $" . number_format($trend['salary']) . "/year<br>";
                echo "</div>";
            }
            echo "</div>";
        }
    }
    ?>

</div>

<?php include 'templates/footer.php'; ?>
