<?php include 'templates/header.php'; ?>
<?php include 'db.php'; ?>

<div class="admin-container">
    <h1>Submitted Student Profiles</h1>

    <?php
    // Fetch all students from the database
    $sql = "SELECT * FROM students";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($students) {
        echo "<table class='students-table'>";
        echo "<thead>";
        echo "<tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Educational Details</th>
                <th>Field of Interest</th>
                <th>Skills</th>
                <th>Location</th>
                <th>Financial Condition</th>
              </tr>";
        echo "</thead>";
        echo "<tbody>";

        // Loop through the students and display each row
        foreach ($students as $student) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($student['id']) . "</td>";
            echo "<td>" . htmlspecialchars($student['name']) . "</td>";
            echo "<td>" . htmlspecialchars($student['email']) . "</td>";
            echo "<td>" . htmlspecialchars($student['educational_details']) . "</td>";
            echo "<td>" . htmlspecialchars($student['field_of_interest']) . "</td>";
            echo "<td>" . htmlspecialchars($student['skills']) . "</td>";
            echo "<td>" . htmlspecialchars($student['location']) . "</td>";
            echo "<td>" . htmlspecialchars($student['financial_condition']) . "</td>";
            echo "</tr>";
        }

        echo "</tbody>";
        echo "</table>";
    } else {
        echo "<p>No student profiles have been submitted yet.</p>";
    }
    ?>

</div>

<?php include 'templates/footer.php'; ?>
