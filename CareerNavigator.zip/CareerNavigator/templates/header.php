<!DOCTYPE html>
<html>
<head>
    <title>CareerNavigator</title>
    <link rel="stylesheet" href="static/style.css">
</head>
<body>
