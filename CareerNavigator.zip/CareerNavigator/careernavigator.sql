-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 07, 2024 at 07:06 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `careernavigator`
--

-- --------------------------------------------------------

--
-- Table structure for table `api_sources`
--

CREATE TABLE `api_sources` (
  `id` int(11) NOT NULL,
  `source_name` varchar(100) DEFAULT NULL,
  `api_url` varchar(255) DEFAULT NULL,
  `last_fetched` date DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `industry_trends`
--

CREATE TABLE `industry_trends` (
  `id` int(11) NOT NULL,
  `industry_name` varchar(255) DEFAULT NULL,
  `subject_needed` varchar(255) DEFAULT NULL,
  `demand_level` varchar(255) DEFAULT NULL,
  `projected_growth` decimal(5,2) DEFAULT NULL,
  `average_salary` decimal(10,2) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `industry_trends`
--

INSERT INTO `industry_trends` (`id`, `industry_name`, `subject_needed`, `demand_level`, `projected_growth`, `average_salary`, `state`) VALUES
(1, 'Software Development', 'Computer Science', 'High', 15.50, 90000.00, 'NSW'),
(2, 'Data Science', 'Mathematics', 'High', 25.00, 100000.00, 'NSW'),
(3, 'Healthcare', 'Nursing', 'High', 20.00, 75000.00, 'Victoria'),
(4, 'Construction', 'Civil Engineering', 'Medium', 10.00, 85000.00, 'Queensland'),
(5, 'Renewable Energy', 'Environmental Science', 'High', 18.00, 80000.00, 'Western Australia');

-- --------------------------------------------------------

--
-- Table structure for table `recommendations`
--

CREATE TABLE `recommendations` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `industry` varchar(100) DEFAULT NULL,
  `projected_growth` decimal(5,2) DEFAULT NULL,
  `average_salary` decimal(10,2) DEFAULT NULL,
  `recommendation_text` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `educational_details` text DEFAULT NULL,
  `field_of_interest` text DEFAULT NULL,
  `skills` text DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `financial_condition` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `email`, `educational_details`, `field_of_interest`, `skills`, `location`, `financial_condition`) VALUES
(1, 'Akash Barai', 'Akashbarai80@gmail.com', 'Marketing', 'Accounting', ' Problem Solving', 'NSW', 'Self-Sufficient');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `api_sources`
--
ALTER TABLE `api_sources`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `industry_trends`
--
ALTER TABLE `industry_trends`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recommendations`
--
ALTER TABLE `recommendations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `api_sources`
--
ALTER TABLE `api_sources`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `industry_trends`
--
ALTER TABLE `industry_trends`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `recommendations`
--
ALTER TABLE `recommendations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `recommendations`
--
ALTER TABLE `recommendations`
  ADD CONSTRAINT `recommendations_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
