<?php include 'templates/header.php'; ?>

<div class="hero">
    <div class="hero-content">
        <h1>Welcome to <span>CareerNavigator</span></h1>
        <p>Explore career paths and educational opportunities tailored just for you, based on your interests, skills, and Australia’s latest job market trends.</p>
        <div class="cta-buttons">
            <a href="student_form.php" class="cta-primary">Create Your Profile</a>
            <a href="admin.php" class="cta-secondary">Admin Login</a>
        </div>
    </div>
</div>

<div class="features-section">
    <h2>Why Use CareerNavigator?</h2>
    <div class="features-grid">
        <div class="feature">
            <h3>Personalized Career Insights</h3>
            <p>Get career recommendations based on real-time data from Australia’s leading job platforms and government sources.</p>
        </div>
        <div class="feature">
            <h3>Up-to-date Job Market Trends</h3>
            <p>Stay informed with the latest industry trends, projected job growth, and salary information across different states and territories.</p>
        </div>
        <div class="feature">
            <h3>Future-proof Your Career</h3>
            <p>Choose career paths that are projected to grow, ensuring that you have stable and high-demand opportunities ahead.</p>
        </div>
    </div>
</div>

<?php include 'templates/footer.php'; ?>
